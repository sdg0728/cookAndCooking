package com.proj.cookingAndCook;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class PayController {
	
}
