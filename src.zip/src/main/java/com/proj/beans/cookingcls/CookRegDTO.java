package com.proj.beans.cookingcls;

import lombok.Data;

@Data
public class CookRegDTO {
	
	private String username;
	private int cno;
	private int user_id;
	
}
