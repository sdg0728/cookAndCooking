package com.proj.beans.cookingcls;

import lombok.Data;

@Data
public class UserInfoDTO {
	
	private int user_id;
	private String email;
	private double score;

}
