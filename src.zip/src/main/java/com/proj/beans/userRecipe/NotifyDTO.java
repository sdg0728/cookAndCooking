package com.proj.beans.userRecipe;


import lombok.Data;

// DTO : Data Transfer Object
@Data
public class NotifyDTO {
	private int user_rid; // post_id
	private int user_id; //ID
	}
		

// end DTO

