package com.proj.beans.userRecipe;

import lombok.Data;

@Data
public class PreferenceDTO {
	private int user_id;
	private int user_rid;
	private double preference;
}
