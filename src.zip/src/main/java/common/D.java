package common;

import org.apache.ibatis.session.SqlSession;

public class D {
	// MyBatis 용 SqlSession
	public static SqlSession sqlSession;
}
