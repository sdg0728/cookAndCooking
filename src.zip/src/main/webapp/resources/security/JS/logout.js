$(".logout").click(function() {
	$("form[name=logoutFrm]").submit();
});